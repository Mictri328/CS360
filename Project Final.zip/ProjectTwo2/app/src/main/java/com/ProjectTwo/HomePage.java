package com.ProjectTwo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class HomePage extends AppCompatActivity {
    //references to layout
    Button addNew, viewall;
    EditText weight, date;
    ListView list;

    DataBaseHelper dataBaseHelper;
    ArrayAdapter userArrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        addNew = findViewById(R.id.addNew);
        viewall = findViewById(R.id.viewall);
        weight = findViewById(R.id.weight);
        date = findViewById(R.id.date);
        list = findViewById(R.id.list);

        dataBaseHelper = new DataBaseHelper(HomePage.this);

        ShowUsersOnListView(dataBaseHelper);

        // click listeners


        addNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserData userData;
                try {
                    userData = new UserData(-1, Integer.parseInt(weight.getText().toString()), date.getText().toString());
                    Toast.makeText(HomePage.this, userData.toString(), Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(HomePage.this, "Error adding weight/date", Toast.LENGTH_SHORT).show();
                    userData = new UserData(-1, 0, "Error Check Format");
                }

                DataBaseHelper dataBaseHelper = new DataBaseHelper(HomePage.this);
                boolean success = dataBaseHelper.addOne(userData);

                //Toast.makeText(HomePage.this, "Success" + success, Toast.LENGTH_SHORT).show();
                ShowUsersOnListView(dataBaseHelper);

            }
        });


        viewall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(HomePage.this, "View Alll Button", Toast.LENGTH_SHORT).show();
                DataBaseHelper dataBaseHelper = new DataBaseHelper(HomePage.this);


                ShowUsersOnListView(dataBaseHelper);
                //Toast.makeText(HomePage.this, all.toString(),Toast.LENGTH_SHORT).show();
            }
        });

        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                UserData clickedUser = (UserData) parent.getItemAtPosition(position);
                dataBaseHelper.deleteOne(clickedUser);
                ShowUsersOnListView(dataBaseHelper);
                Toast.makeText(HomePage.this, "Deleted", Toast.LENGTH_SHORT).show();

                return true;
            }
        });







    }





    private void ShowUsersOnListView(DataBaseHelper dataBaseHelper2) {
        userArrayAdapter = new ArrayAdapter<UserData>(HomePage.this, android.R.layout.simple_list_item_1, dataBaseHelper2.getAll());
        list.setAdapter(userArrayAdapter);
    }

    ;
}
