package com.ProjectTwo;

public class UserData {

    private int id;
    private int weight;
    private String date;

//constructors

    public UserData(int id, int weight, String date) {
        this.id = id;
        this.weight = weight;
        this.date = date;
    }

    public UserData() {

    }

    @Override
    public String toString() {
        return " weight -  " + weight + "Lbs " +
                " , date : '" + date + '\'';
    }

    //getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
